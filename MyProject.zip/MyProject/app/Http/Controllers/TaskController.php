<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;
use App\Models\task;

class TaskController extends Controller
{
    public function index(){
        // $tasks = DB::select('select * from tasks');
        $tasks = Task::get();
        return view('auth.dashboard', ['tasks'=>$tasks]);
    }

    public function create(Request $request){

        $request->validate([
            'task' => 'required',
            
        ]);
        // dd($request->all());
        $task = new task;
        $task->tasks = $request->task;
        $task->save();

        return back()->withSuccess('New Task Added');

    }

    public function edit($id){
        $taskname = task::where('id', $id)->first();
        // $taskname = DB::table('tasks')->where('id', $id)->first();
        //dd($taskname->tasks);
        return view('edit',['taskedit'=>$taskname] );
    }

    public function update(Request $request, $id){
        $request->validate([
            'task' => 'required',
            
        ]);
        $taskupdate = task::where('id', $id)->first();
        // dd($id);
        // $taskupdate = task::where('id', $id)->update([$request->task]);
        $taskupdate->tasks = $request->task;
        $taskupdate->save();

        // return back()->withSuccess('Task Updated');
        // return view('dashboard');
        return redirect()->route('dashboard.view');
    }

    public function destroy($id){
        $taskdelete = task::where('id', $id)->first();
        $taskdelete->delete();
        return back()->withSuccess('Task Deleted');
    }
    
}
