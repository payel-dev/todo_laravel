<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class ViewTaskController extends Controller
{
    public function index(){
        $tasks = DB::select('select * from tasks');
        return view('auth.dashboard', ['tasks'=>$tasks]);
    }
}
