@extends('layouts.header')
@section('main')
    <div class="container container-fluid">
        <nav class="navbar">
            <div class="navbar-header">
                <span class="text-right">
                    <a class="navbar-btn btn btn-info btn-primary navbar-right" href="{{ route('logout') }}">Log Out</a>
                </span>
                
            </div>
        </nav>
        <h3>Todo Tasks</h3>
        <div>
            <table border="1" margin="1" class="table table-striped">
                <tr>
                    <th>Task ID</th>
                    <th>Task Lists</th>
                    <th>Action</th>
                </tr>
                @foreach ($tasks as $task)
                <tr>
                    <td class=".col-sm-4">{{ $task->id }}</td>
                    <td class=".col-sm-8">{{ $task->tasks }}</td>
                    <td class=".col-sm-8"><a href="{{ route('dashboard.edit', ['id' => $task->id] ) }}">Edit</a> | <a href="{{ route('dashboard.destroy', ['id' => $task->id] ) }}">Delete</a></td>
                    {{-- <td><a href="dashboard/{{ $task->id }}/edit">Edit</a> | <a href="dashboard/{{ $task->id }}/delete">Delete</a></td> --}}
                </tr>
                @endforeach
            </table>
        </div>
        <br><br>
        <div class="justify-content-center">
            <div class="col-sm-8">
                <form method="POST" action={{ route('dashboard.tasks') }}>
                    @csrf
                    <div class="form-group">
                        <input type="text" name="task" class="form-control" placeholder="Input your task to do" >
                        @if ($errors->has('task'))
                            <span class="text-danger">{{ $errors->first('task') }}</span>
                        @endif
                    </div>
                    <input type="submit" name="add" class="btn btn-default" value="Add Task">
                </form>
            </div>
        </div>

    </div>
    
@endsection