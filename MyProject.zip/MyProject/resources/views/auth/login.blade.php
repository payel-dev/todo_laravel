@extends('layouts.header')
    @section('main')
        <div class="container">
            <h1>Login Page</h1>
            
            <div class="col-sm-4">
                <form method="POST" action="{{ route('login.custom') }}">
                    @csrf
                    <div class="form-group">
                        <label for="usr">Username: </label>
                        <input type="text" name="email" class="form-control" placeholder="Enter your email" value="{{ old('email') }}">
                        @if ($errors->has('email'))
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                        @endif
                        
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password: </label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" value="{{ old('password') }}">
                        @if ($errors->has('password'))
                            <span class="text-danger">{{ $errors->first('password') }}</span>
                        @endif
                        
                    </div>
                        <input type="submit" name="submit" class="btn btn-default" value="Login">
                </form>
            </div>
        </div>
    @endsection