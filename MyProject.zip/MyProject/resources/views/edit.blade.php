@extends('layouts.header')
    @section('main')
        <div class="container">
            <div class="justify-content-center">
                <div class="col-sm-8">
                    <h3 class="text-muted">Edit #{{ $taskedit->tasks }}</h3>
                    <form method="POST" action='{{ route('dashboard.tasks') }}/{{ $taskedit->id }}/update'>
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <input type="text" name="task" class="form-control" placeholder="Input your task to do" value="{{ $taskedit->tasks }}">
                            @if ($errors->has('task'))
                                <span class="text-danger">{{ $errors->first('task') }}</span>
                            @endif
                        </div>
                        <input type="submit" name="add" class="btn btn-default" value="Add Task">&nbsp;
                        <a href="{{ route('dashboard.tasks') }}">Back</a>
                    </form>
                </div>
            </div>
        </div>
        
    @endsection