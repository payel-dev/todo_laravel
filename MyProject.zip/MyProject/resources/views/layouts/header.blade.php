<!DOCTYPE html>
<html>
    <head>
        <title>ToDo List</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        {{-- <div class="card-header"><strong>Dashboard</strong></div> --}}
        
            <div class="card">
                <div class="card-header">
                    <div class="card-body">
                        @if ($message = Session::get('success'))
                            <div class="alert alert-success">
                                
                                {{ $message }}
                            </div> 
                                                
                        @endif

                        @if($message = Session::get('error'))
                            <div class="alert alert-danger alert-block" role="alert">
                                {{ $message }}
                                {{-- {{ Session::get("error") }} --}}
                            </div>
                        @endif
                    </div>
                </div>
           
            @yield('main')
        <script>
            $("document").ready(function(){
                setTimeout(function(){
                $("div.alert").remove();
                }, 5000 ); // 5 secs

            });
        </script>
    </body>
</html>
            