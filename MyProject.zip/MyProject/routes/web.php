<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TaskController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('login');
// });


// Login Routes
Route::get('dashboard', [UserController::class, 'dashboard'])->name('dashboard');
Route::get('login', [UserController::class, 'index'])->name('login');
Route::post('custom-login', [UserController::class, 'customLogin'])->name('login.custom');

// Dashboard Routes
Route::get('dashboard', [TaskController::class, 'index'])->name('dashboard.view');
Route::post('dashboard', [TaskController::class, 'create'])->name('dashboard.tasks');

// Edit Routes
Route::get('dashboard/{id}/edit', [TaskController::class, 'edit'])->name('dashboard.edit');
Route::put('dashboard/{id}/update', [TaskController::class, 'update'])->name('dashboard.update');

// Delete Route
Route::get('dashboard/{id}/delete', [TaskController::class, 'destroy'])->name('dashboard.destroy');

// Logout
Route::get('logout', [UserController::class, 'logout'])->name('logout');