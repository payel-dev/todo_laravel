
    <?php $__env->startSection('main'); ?>
        <div class="container">
            <div class="justify-content-center">
                <div class="col-sm-8">
                    <h3 class="text-muted">Edit #<?php echo e($taskedit->tasks); ?></h3>
                    <form method="POST" action='<?php echo e(route('dashboard.tasks')); ?>/<?php echo e($taskedit->id); ?>/update'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <input type="text" name="task" class="form-control" placeholder="Input your task to do" value="<?php echo e($taskedit->tasks); ?>">
                            <?php if($errors->has('task')): ?>
                                <span class="text-danger"><?php echo e($errors->first('task')); ?></span>
                            <?php endif; ?>
                        </div>
                        <input type="submit" name="add" class="btn btn-default" value="Add Task">&nbsp;
                        <a href="<?php echo e(route('dashboard.tasks')); ?>">Back</a>
                    </form>
                </div>
            </div>
        </div>
        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\MyProject\resources\views/edit.blade.php ENDPATH**/ ?>