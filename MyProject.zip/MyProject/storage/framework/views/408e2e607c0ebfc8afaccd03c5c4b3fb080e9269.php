
<?php $__env->startSection('main'); ?>
    <div class="container container-fluid">
        <nav class="navbar">
            <div class="navbar-header">
                <span class="text-right">
                    <a class="navbar-btn btn btn-info btn-primary navbar-right" href="<?php echo e(route('logout')); ?>">Log Out</a>
                </span>
                
            </div>
        </nav>
        <h3>Todo Tasks</h3>
        <div>
            <table border="1" margin="1" class="table table-striped">
                <tr>
                    <th>Task ID</th>
                    <th>Task Lists</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=".col-sm-4"><?php echo e($task->id); ?></td>
                    <td class=".col-sm-8"><?php echo e($task->tasks); ?></td>
                    <td class=".col-sm-8"><a href="<?php echo e(route('dashboard.edit', ['id' => $task->id] )); ?>">Edit</a> | <a href="<?php echo e(route('dashboard.destroy', ['id' => $task->id] )); ?>">Delete</a></td>
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <br><br>
        <div class="justify-content-center">
            <div class="col-sm-8">
                <form method="POST" action=<?php echo e(route('dashboard.tasks')); ?>>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" name="task" class="form-control" placeholder="Input your task to do" >
                        <?php if($errors->has('task')): ?>
                            <span class="text-danger"><?php echo e($errors->first('task')); ?></span>
                        <?php endif; ?>
                    </div>
                    <input type="submit" name="add" class="btn btn-default" value="Add Task">
                </form>
            </div>
        </div>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\MyProject\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>