
    <?php $__env->startSection('main'); ?>
        <div class="container">
            <h1>Login Page</h1>
            
            <div class="col-sm-4">
                <form method="POST" action="<?php echo e(route('login.custom')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="usr">Username: </label>
                        <input type="text" name="email" class="form-control" placeholder="Enter your email" value="<?php echo e(old('email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                        
                    </div>
                    <div class="form-group">
                        <label for="pwd">Password: </label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" value="<?php echo e(old('password')); ?>">
                        <?php if($errors->has('password')): ?>
                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                        
                    </div>
                        <input type="submit" name="submit" class="btn btn-default" value="Login">
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\MyProject\resources\views/auth/login.blade.php ENDPATH**/ ?>