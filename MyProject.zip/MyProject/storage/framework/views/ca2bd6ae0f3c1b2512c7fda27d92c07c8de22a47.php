<h1>Login Page</h1>
<form method="post" action="<?php echo e(route('dashboard')); ?>">
    <?php echo csrf_field(); ?>
    <label>Username: </label>
    <input type="text" name="username" placeholder="email" required>
    <?php if($errors->has('email')): ?>
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
    <?php endif; ?>
    <br><br>

    <label>Password: </label>
    <input type="password" name="password" placeholder="password" required>
    <?php if($errors->has('password')): ?>
        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
    <?php endif; ?>
    <br><br>

    <input type="submit" name="submit" value="Login">
</form>
<?php /**PATH D:\xampp\htdocs\MyProject\resources\views/login.blade.php ENDPATH**/ ?>